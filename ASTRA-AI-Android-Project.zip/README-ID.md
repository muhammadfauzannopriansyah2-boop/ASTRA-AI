# ASTRA AI Android
Ini project Android client untuk ASTRA AI.

API KEY TIDAK dimasukkan ke APK. Simpan di backend:
OPENAI_API_KEY=API_KEY_BARU_KAMU
PORT=3000

Jangan gunakan key yang pernah dibagikan di chat; revoke dan buat key baru.

Untuk testing emulator, backend di komputer dapat diakses melalui http://10.0.2.2:3000.
Untuk HP fisik, ubah URL di MainActivity.java menjadi http://IP-KOMPUTER:3000 dan pastikan satu jaringan.

Build APK: buka project di Android Studio/Android IDE yang mendukung Android Gradle Plugin, lalu Build > Build APK(s).
Model AI asli dipanggil oleh backend melalui API resmi.
